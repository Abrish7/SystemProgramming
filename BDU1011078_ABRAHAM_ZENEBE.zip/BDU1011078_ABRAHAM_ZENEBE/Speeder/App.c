#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<stdlib.h>
#include <stdio.h>
#include<process.h>

void main()
{
	repeat:
		printf("				PRESS ANY KEY TO START \n");
		getchar();
    printf("\n\n\n			======================================\n");
    printf("				BAHIR DAR UNIVERSITY \n");
    printf("			======================================\n\n");
    printf("			======================================\n");
    printf("				SYSTEM PTOGRAMMING PROJECT \n");
    printf("			======================================\n");
    printf("					SPEEDER \n");
    printf("			======================================\n\n\n");
    printf("			======================================\n");
    printf("				DEVELOPED BY ABRAHAM ZENEBE \n");
    printf("			======================================\n\n\n");
    printf("			to speed up your window at least\n");
	printf(" 			you need to clean unused data from listed below\n\n");
	printf("				A. PRESS 1 TO CLEAN ALL TEMPRARY FOLDER IN WINDOWS\n");
	printf("				B. PRESS 2 TO CLEAN ALL CATCH DATA THAT MAKE YOUR PC SLOWER\n");
	printf("				C. PRESS 3 TO CLEAN APPDATA CATCHS\n");
	printf("				D. PRESS 4 TO CLEAN BROWSER COOKIES\n");
    printf("				E. PRESS 5 TO EXIT\n\n");
    
    char chr;
    printf("			======== Enter Choosen Number: ");
    scanf("%c",&chr);    
	
	
	if(chr == '1'){
			printf("			YOU CHOOSE TO CLEAN ALL TEMPRARY FOLDER IN WINDOWS\n");	
			printf("				press enter to continue.. \n");
		    getchar();
		    getchar();
		    //=======================================================================================
			system("RemoveTempoFile.bat");				//excute Batch File Named RemoveTempoFile.bat in the current directory
			//=======================================================================================										 
			printf("\n\n\n\n\n			======================================\n");	
		    printf("			Temporary Folder Are Succesfully Removed! \n");
		    printf("				press enter to continue.. \n");
		    printf("			======================================\n\n");
		    getchar();
			system("cls");
			goto repeat;
	}
    else if(chr == '2'){
    		printf("\n			YOU CHOOSE TO CLEAN ALL CATCH DATA THAT MAKE YOUR PC SLOWER\n");
    		printf("				press enter to continue.. \n");
    	    getchar();
    	    getchar();
    	    //=======================================================================================	
    	    system("CleanAllData.bat"); 							//excute Batch File Named CleanAllData.bat in the current directory
     		system("RemoveBrowserCookies.bat");									//excute Batch File Named browserCookies.bat in the current directory
     		system("Clear.bat");									//excute Batch File Named Clear.bat in the current directory
     		system("RemoveTempoFile.bat");							//excute Batch File Named RemoveTempoFile.bat in the current directory
     		//=======================================================================================	
		    printf("\n\n\n\n\n			======================================\n");
		    printf("			All catched data Succesfully Removed.. \n");
		    printf("				press enter to continue.. \n");
		    printf("			======================================\n\n");
		    getchar();
     		system("cls");
			goto repeat;
    }
    else if(chr == '3'){
    	printf("\n			YOU CHOOSE TO CLEAN APPDATA CATCHS\n");
    	printf("				press enter to continue.. \n");
        getchar();
        getchar();
        	//=======================================================================================	
	    system("CleanAPPData.bat"); 							//excute Batch File Named CleanAPPData.bat in the current directory
	    	//=======================================================================================	
	    printf("\n\n\n\n\n			======================================\n");
	    printf("			AppData are cleaned Succesfully Removed.. \n");
	    printf("				press enter to continue.. \n");
	    printf("			======================================\n\n");
	    getchar();
    	system("cls");
    	goto repeat;
    }
	else if(chr == '4'){
		printf("\n			YOU CHOOSE TO CLEAN BROWSER COOKIES\n");
		printf("				press enter to continue.. \n");
		getchar();
	    getchar();
	    //=======================================================================================
		system("browserCookies.bat");										//excute Batch File Named browserCookies.bat in the current directory
		//=======================================================================================
		printf("\n\n\n\n\n			======================================\n");
	    printf("			Browser Cookies are cleaned Succesfully Removed.. \n");
	    printf("				press enter to continue.. \n");
	    printf("			======================================\n\n");
	    getchar();
		system("cls");
		goto repeat;
	}
	else if(chr == '5'){
		return;
	}
	else
		printf("wrong answer");
		system("cls");
		goto repeat;
	
     
     getch();
 }
